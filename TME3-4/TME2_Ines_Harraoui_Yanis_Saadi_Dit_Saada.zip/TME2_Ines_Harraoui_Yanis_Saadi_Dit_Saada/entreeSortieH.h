#include <stdio.h>
#include <stdlib.h>
#include "biblioH.h"

BiblioH* charger_n_entrees_H(char* nomfic, int n, int m);
void enregistrer_biblio_H(BiblioH *b, char* nomfic);