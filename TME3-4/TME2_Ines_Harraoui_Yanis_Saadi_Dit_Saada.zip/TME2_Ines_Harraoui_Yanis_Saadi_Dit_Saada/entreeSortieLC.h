#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "biblioLC.h"

Biblio* charger_n_entrees_LC(char* nomfic, int n);
void enregistrer_biblio_LC(Biblio *b, char* nomfic);
